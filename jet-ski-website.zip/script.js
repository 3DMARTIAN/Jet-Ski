function startRide() {
    alert("Hold tight! Let's ride the waves!");
}
